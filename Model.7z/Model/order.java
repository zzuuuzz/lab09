
import java.util.*;

/**
 * 
 */
public class order {

    /**
     * 
     */
    public order() {
    }

    /**
     * 
     */
    public void date;

    /**
     * 
     */
    public void user;


}