
import java.util.*;

/**
 * 
 */
public class User {

    /**
     * 
     */
    public User() {
    }

    /**
     * 
     */
    public void Name;

    /**
     * 
     */
    public void Surname;



}