
import java.util.*;

/**
 * 
 */
public class Subscriber {

    /**
     * 
     */
    public Subscriber() {
    }

    /**
     * 
     */
    public void telephone;

    /**
     * 
     */
    public void adress;



}