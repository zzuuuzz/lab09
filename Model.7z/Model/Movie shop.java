
import java.util.*;

/**
 * 
 */
public class Movie shop {

    /**
     * 
     */
    public Movie shop() {
    }

    /**
     * 
     */
    public void listMovies;

    /**
     * 
     */
    public void order;

    /**
     * 
     */
    public void subscribe;




}