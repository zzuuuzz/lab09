
import java.util.*;

/**
 * 
 */
public class movie rent extends movie {

    /**
     * 
     */
    public movie rent() {
    }

    /**
     * 
     */
    public void location;

    /**
     * 
     */
    public void hire date;

    /**
     * 
     */
    public void price;

}