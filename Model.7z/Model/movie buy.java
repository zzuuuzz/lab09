
import java.util.*;

/**
 * 
 */
public class movie buy extends movie {

    /**
     * 
     */
    public movie buy() {
    }

    /**
     * 
     */
    public void country;

    /**
     * 
     */
    public void sell price;


}