
import java.util.*;

/**
 * 
 */
public class Card {

    /**
     * 
     */
    public Card() {
    }

    /**
     * 
     */
    public void credit;

    /**
     * 
     */
    public void code;


}