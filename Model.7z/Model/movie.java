
import java.util.*;

/**
 * 
 */
public class movie {

    /**
     * 
     */
    public movie() {
    }

    /**
     * 
     */
    public void name;

    /**
     * 
     */
    public void type DVD VHS;


}